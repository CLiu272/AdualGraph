clear
clc

addpath(genpath(pwd))
load Microarray.mat

option = 5; % AdualGraph
%lambda_opt = 1;
%lambda2_opt = 10;
AdualGraph_nMSE = Evaluate(X_train,Y_train,X_test,Y_test,lambda1_opt,lambda2_opt,option);

[W,R] = AdaptDualGraphMTL_Regression( X_train,Y_train,lambda1_opt,lambda2_opt,lambda3_opt );

%% Visualization ---
group = SpectralClustering(double(R),clusterNum);
R = (R +R')/2;
R = R - diag(diag(R));
%%% Normalize the task relationship
n = length(R);
R(R<median(R(:)))=0;
U = unique(group);
allindex = [];
position = 0;
for i = 1 : length(U)
    index = find(group==U(i));
    allindex = [allindex;index];
    groupnew(position(i)+1:position(i)+length(index)) = index;
    position(i+1) = position(i)+length(index);
end

imagesc(R(allindex,allindex));

fprintf('The predication result of AdualGraph is %f\n',AdualGraph_nMSE );