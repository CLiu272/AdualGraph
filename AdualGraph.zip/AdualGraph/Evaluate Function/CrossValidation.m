function [ lambda_opt,perform_mat ] = CrossValidation( X,Y,cv_fold,option,lambda_range)
%CROSS-VALIDATION (Modify from MALSAR, hence please cite >> )

task_num = length(X);

perform_mat = zeros(length(lambda_range),1);

for cv_idx = 1: cv_fold
   
    % buid cross validation data splittings for each task.
    cv_Xtr = cell(task_num, 1);
    cv_Ytr = cell(task_num, 1);
    cv_Xte = cell(task_num, 1);
    cv_Yte = cell(task_num, 1);
    
    for t = 1: task_num
        task_sample_size = length(Y{t});
        te_idx = cv_idx : cv_fold : task_sample_size;
        tr_idx = setdiff(1:task_sample_size, te_idx);
        
        cv_Xtr{t} = X{t}(tr_idx, :);
        cv_Ytr{t} = Y{t}(tr_idx, :);
        cv_Xte{t} = X{t}(te_idx, :);
        cv_Yte{t} = Y{t}(te_idx, :);
    end
    
    for lam_idx = 1: length(lambda_range)
        lambda1 = lambda_range(lam_idx);
        lambda2 = lambda1;
        [ Predict_performance] = Evaluate( cv_Xtr,cv_Ytr,cv_Xte,cv_Yte,lambda1,lambda2,option );
        perform_mat(lam_idx) = perform_mat(lam_idx) + Predict_performance;
    end
        
end

perform_mat = perform_mat./cv_fold;
    
[~,best_idx] = min(perform_mat);

lambda_opt = lambda_range(best_idx);

end

