function [ lambda_opt1,lambda_opt2 ] = validation1( X_train,Y_train,X_validation,Y_validation,option,lambda_range1,lambda_range2 )

perform_mat = zeros(length(lambda_range1),length(lambda_range2));
imse = zeros(length(lambda_range1),length(lambda_range2),length(Y_train));


for i = 1: length(lambda_range1)
    for j = 1: length(lambda_range2)
        [ Predict_performance,~,imseMatrix] = Evaluate( X_train,Y_train,X_validation,Y_validation,lambda_range1(i),lambda_range2(j),option );
        perform_mat(i,j) =  Predict_performance;
        imse(i,j,:) = imseMatrix;
    end
end



for k = 1:length(Y_train) 

    opt_perform = 10000;
    best_idx_i = 1;
    best_idx_j = 1;
    
    for i = 1:length(lambda_range1)
        for j = 1:length(lambda_range2)
            if imse(i,j,k) < opt_perform
                opt_perform = imse(i,j,k);
                best_idx_i = i;
                best_idx_j = j;
            end
        end
    end
    lambda_opt1(k) = lambda_range1(best_idx_i);
    lambda_opt2(k) = lambda_range2(best_idx_j);
end



end

