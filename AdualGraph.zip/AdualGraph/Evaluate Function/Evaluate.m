function [ Predict_performance,W,imse] = Evaluate( X_train,Y_train,X_test,Y_test,lambda1,lambda2,option )
%%EVALUATE
% X : {n*p}*m
% options: 1 (sparse exclusive lasso)
%          2 (lasso)
%          3 (L21 norm) 


% task_num = length(X_train);
% sample_num = length(Y_test{1});

switch (option)
    case 1
        [W] = Least_Lasso(X_train,Y_train,lambda1);
    case 2
        [W] = Least_L21(X_train,Y_train,lambda1);
    case 3
        [W] = Least_Trace(X_train,Y_train,lambda1);
    case 4
        [W] = Least_CMTL(X_train,Y_train,lambda1,lambda2,5);
    case 5
        [W] = AdaptDualGraphMTL_Regression( X_train,Y_train,lambda1,lambda2,lambda1 );
        % microarray lambda3 = lambda1;
        % School data lambda3 = lambda2/5;
    case 6
        [W] = GOMTL_Least(X_train, Y_train, lambda1,lambda2,20);
    otherwise
        disp('the variable option must be number from 1 to 6');
end

[Predict_performance] = eval_nMTL_mse (Y_test, X_test, W);
    
end

