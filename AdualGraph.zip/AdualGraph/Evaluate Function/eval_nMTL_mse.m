function [nmse,imse] = eval_nMTL_mse (Y, X, W)
%% FUNCTION eval_MTL_mse

task_num = length(X);
nmse = 0;
for t = 1: task_num
    YPred = X{t} * W(:, t);
    %nmse = nmse + (mean((y_pred-Y{t}).^2))/(var(Y{t})+0.01);
    imse(t) = (norm(YPred-Y{t})^2/length(YPred))/var(Y{t});
    nmse = nmse + imse(t);
end

nmse = nmse/task_num;
    
end
