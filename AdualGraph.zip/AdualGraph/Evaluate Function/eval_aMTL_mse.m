function nmse = eval_aMTL_mse (Y, X, W)
%% FUNCTION eval_MTL_mse

task_num = length(X);
nmse = 0;

for t = 1: task_num
    y_pred = X{t} * W(:, t);
    nmse = nmse + (mean(norm(y_pred-Y{t})^2))/norm(Y{t})^2;
end

nmse = nmse/task_num;
    
end
