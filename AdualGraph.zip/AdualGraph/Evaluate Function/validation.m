function [ lambda_opt1,lambda_opt2 ] = validation( X_train,Y_train,X_validation,Y_validation,option,lambda_range1,lambda_range2 )

perform_mat = zeros(length(lambda_range1),length(lambda_range2));

for i = 1: length(lambda_range1)
    for j = 1: length(lambda_range2)
        [ Predict_performance] = Evaluate( X_train,Y_train,X_validation,Y_validation,lambda_range1(i),lambda_range2(j),option );
        perform_mat(i,j) =  Predict_performance;
    end
end

opt_perform = 10000;
best_idx_i = 1;
best_idx_j = 1;
for i = 1:length(lambda_range1)
    for j = 1:length(lambda_range2)
        if perform_mat(i,j) < opt_perform
            opt_perform = perform_mat(i,j);
            best_idx_i = i;
            best_idx_j = j;
        end
    end
end

lambda_opt1 = lambda_range1(best_idx_i);
lambda_opt2 = lambda_range2(best_idx_j);

end

