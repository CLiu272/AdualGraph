function [ C ] = ConstructStructure( R,task_num )
%CONSTRUCTTASKSTRUCTURE 

%UR = triu(R,1); %upper triangluar of C
%LR = tril(R,1);

V = R - diag(diag(R));
nV = task_num;

nzUR = find(V~=0);
[E1,E2] = ind2sub([nV,nV],nzUR);
E = [E1,E2];
nE = size(E,1);
Ecoef = V(nzUR);
Esign = sign(R(nzUR));

C_I = [(1:nE)';(1:nE)'];
C_J = [E1;E2];
C_S = [Ecoef, -Ecoef.*Esign];
C = sparse(C_I, C_J, C_S, nE, nV);

end

