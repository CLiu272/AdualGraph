function [ S ] = CalGraph( W,k )
%ESTIMATETASKSTRUCTURE 
mu = 10e-4;
alpha = 1;
n = size(W,1);

distW =  L2_distance_1(W',W');

S = zeros(n);

[~, idx] = sort(distW,2);

for i=1:n
    idxa0 = idx(i,2:k+1);
    dxi = distW(i,idxa0)+eps;
    distK = sum((dxi)/(alpha))/k;
    distFull = distW(i,:);
    d = (distK - distFull);
    d(find(d<=0)) = 0;
    d(i) = 0;
    S(i,:) = d;
    S(i,:) = d./(sum(d)+eps);    
end



end

