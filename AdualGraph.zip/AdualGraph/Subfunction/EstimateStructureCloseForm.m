function [ R ] = EstimateStructureCloseForm(W)
%ESTIMATETASKSTRUCTURE 
num = size(W,2);

mu = 10;
for i = 1:num
    omega = zeros(num,1);
    f = zeros(num,1);
    for j = 1:num
        d(j) = norm(W(:,i) - W(:,j));
    end
    
    t = ((1+sum(d))/length(d))*ones(size(d));
    t([1:i-1, i+1:end]) = t([1:i-1, i+1:end]) - d([1:i-1, i+1:end]);
    t(i) = 0;
    t(t<0) = 0;
    t = t./sum(t+eps);
    R(i,:) = t;
    R = sparse(R);
end



end

