MALSAR C-files Readme File
-----------------------------
Some of the libraries in this folder 
are from SLEP package: 

http://www.public.asu.edu/~jye02/Software/SLEP/

Please refer to the SLEP manual for 
technical details or the libraries.




Jiayu Zhou
April 8th 2012 