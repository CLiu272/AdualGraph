% update the elements of a sparse matrix .
% sparse_update(S, v, length(v));
% Note: the following must be hold or the MATLAB crashes 
%     nnz(S) == length(v). 
% TODO: write dimensionality check in c. 