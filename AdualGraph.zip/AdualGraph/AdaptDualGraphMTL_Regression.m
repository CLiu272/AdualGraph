function [ W,Rt ] = AdaptDualGraphMTL_Regression( X,Y,lambda,lambda2,lambda3 )

X = multi_transpose(X);

task_num  = length (X);
dimension = size(X{1},1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
XY = cell(task_num, 1);
n_sum = 0;
W0_prep = [];
for t_idx = 1: task_num
    n_sum = n_sum + length(Y{t_idx});
    XY{t_idx} = X{t_idx}*Y{t_idx};
    W0_prep = cat(2, W0_prep, XY{t_idx});
end
% initialize a starting point
W0 = zeros(dimension, task_num);
W0 = Least_Lasso(multi_transpose(X),Y,lambda); % call MASLAR package



%%%%%%%%%%%%%%%%% Generate graph %%%%%%%%%%%%%%%%%%%
[ Rt ] = EstimateStructureCloseForm( W0 );
[ Rf ] = EstimateStructureCloseForm( W0');
[ St ] = ConstructStructure( Rt,task_num );
[ Sf ] = ConstructStructure( Rf,dimension );

Wz= W0;
Wz_old = W0;

t = 1;
t_old = 0;


iter = 0;
maxIter = 100;
gamma = 1;
gamma_inc = 2;
mu = 1e-4;

funcVal = [];
while iter < maxIter
         
    alpha = (t_old - 1) /t;
    
    Ws = (1 + alpha) * Wz - alpha * Wz_old;
    
    % compute function value and gradients of the search point
    
    At = hard_threshold(full(St*Ws'/mu), 1); 
    Af = hard_threshold(full(Sf*Ws/mu), 1); 

    gWs  = gradVal_eval(Ws) + lambda2 * At'*St + lambda3 * Sf' * Af; 
    Fs   = funVal_eval (Ws); %+ lambda2 * sum(sum(abs(St*Ws'))) + lambda3 * sum(sum(abs(Sf*Ws)));
    
    innIter = 0;
    
    while true
        
        Wzp = l1_projection(Ws - gWs/gamma, 2 * lambda / gamma);
        Fzp = funVal_eval(Wzp); %+ lambda2 * sum(sum(abs(St*Ws'))) + lambda3 * sum(sum(abs(Sf*Ws)));
        
        delta_Wzp = Wzp - Ws;
        Fzp_gamma = Fs + trace(delta_Wzp' * gWs) + gamma/2 * norm(delta_Wzp, 'fro')^2 + lambda2 * sum(sum(abs(St*Wzp'))) + lambda3 * sum(sum(abs(Sf*Wzp)));
        
        if (Fzp <= Fzp_gamma)
            break;
        else
            gamma = gamma * gamma_inc;
        end
        
         
    end
     

    
    funcVal = cat(1, funcVal, Fzp + lambda2 * sum(sum(abs(St*Wzp'))) + lambda3 * sum(sum(abs(Sf*Wzp))));
    
    if iter>=10
        if (abs( funcVal(end) - funcVal(end-1) ) <= 10e-4)
            break;
        end
        if max(max(abs(Wz - Wzp))) < 1e-4 && norm(Wzp)~=0
            disp('finished')
            break;
        end
    end
    
    Wz_old = Wz;
    Wz = Wzp;
        
    
    %%%%%%%%%%%%%%%%% Generate graph %%%%%%%%%%%%%%%%%%%
     [ Rt ] = EstimateStructureCloseForm( Wz );
     [ Rf ] = EstimateStructureCloseForm( Wz');
     [ St ] = ConstructStructure( Rt,task_num );
     [ Sf ] = ConstructStructure( Rf,dimension );
    
    
    %% Update parameter
    iter = iter + 1;
    t_old = t;
    t = 0.5 * (1 + (1+ 4 * t^2)^0.5);
    
end

W = Wzp;


% private functions

    function [z, l1_comp_val] = l1_projection (v, beta)
        
        z = zeros(size(v));
        vp = v - beta/2;
        z (v> beta/2)  = vp(v> beta/2);
        vn = v + beta/2;
        z (v< -beta/2) = vn(v< -beta/2);
        
        
        l1_comp_val = sum(sum(abs(z)));
    end

    function [grad_W] = gradVal_eval(W)
        
        grad_W = [];
        for t_ii = 1:task_num
            XY{t_ii} = X{t_ii}*Y{t_ii};
            XWi = X{t_ii}' * W(:,t_ii);
            XTXWi = X{t_ii}* XWi;
            grad_W = cat(2, grad_W, XTXWi - XY{t_ii});
        end

    end

    function [funcVal] = funVal_eval (W)
        
        funcVal = 0;
        
        for i = 1: task_num
            funcVal = funcVal + 0.5 * norm (Y{i} - X{i}' * W(:, i))^2;
        end
        
        funcVal = funcVal ;
    end


    function [taskloss,taskloss_each] = lossVal(W)
        
        taskloss = [];
        for i = 1:task_num
            taskloss_each{i} = abs(Y{i} - X{i}' * W(:, i));
            taskloss = [taskloss ; taskloss_each{i}];
        end
        
    end


end

